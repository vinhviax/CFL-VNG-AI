# Handoff — Knowledge Base VNG

**Cập nhật:** 14/08/2026  
**Trạng thái:** Bản v3.3.0 và rollout Agent chuyên sâu đã hoàn tất; bản phân phối local cùng dữ liệu Private Weapon đã được ghi nhận; không có migration hoặc mutation live đang chạy.

## Trạng thái hiện tại

| Vai trò | Knowledge Base | Inventory live cuối |
|---|---|---|
| Asset host | `Knowledge VNG - Image Assets` — `6da8657c-dd96-4170-a698-074043475014`, tenant `10012` | 49 PNG, 0 MD; 49/49 **Hoàn tất** |
| Consumer | `Knowledge VNG AI` — `cefadf09-4187-46ac-a765-591e3255a4a4`, tenant `10012` | 20 MD, 0 PNG; 20/20 **Hoàn tất** |

Local hiện có master v3.3.0, 20 module sinh tự động, 49 PNG thật, 49 URI MinIO duy nhất, 60 link ảnh MinIO, 60 `LOCAL_ASSET` và HTML offline tự chứa. Module 13 legacy đã có backup nguyên byte rồi được dọn khỏi consumer sau khi module 13 mới pass source/ảnh. Gate local: strict build PASS, `Ran 13 tests`; live source/ảnh của 13–19 và no-hit PASS; reviewer độc lập **APPROVED**.

## Root làm việc CFL

Người dùng đã chỉ định `J:\My Drive\CFL\KB VNG` làm nơi chứa các folder KB phục vụ công việc. Snapshot filesystem ngày 14/08/2026:

| Thư mục | Nội dung đã xác minh | Vai trò |
|---|---|---|
| `Knowledge VNG AI` | 20 MD | Bản phân phối local của consumer |
| `Knowledge VNG - Image Assets` | 49 PNG | Bản sao asset local |
| `Data Private Weapon` | 7 CSV + 1 JSON raw; 388.820 dòng CSV | Dữ liệu CFL riêng tư, chưa upload live |

Bộ CSV đã được kiểm tra lại: đúng số dòng/cột, UTF-8 hợp lệ, record đầu/cuối khớp nguồn và không còn `.partial`. Hai folder mang tên KB tại đây là mirror/bản làm việc; master và builder trong workspace hiện tại vẫn là nguồn chuẩn.

## Bắt đầu phiên tiếp theo

1. Đọc [STATUS.md](STATUS.md) để biết snapshot và backlog mới nhất.
2. Đọc [AGENTS.md](AGENTS.md) trước mọi thao tác ghi hoặc mutation live.
3. Dùng [PROJECT.md](PROJECT.md) và [DECISIONS.md](DECISIONS.md) cho kiến trúc/quyết định bền vững.
4. Chỉ mở audit/report khi cần bằng chứng; không nạp toàn bộ lịch sử vào context mặc định.
5. Nội dung nghiệp vụ chỉ sửa tại [so-tay-tao-knowledge-base-v3.md](so-tay-tao-knowledge-base-v3.md), không sửa trực tiếp module hoặc HTML.
6. Nếu nhiệm vụ liên quan dữ liệu vũ khí/người dùng, đọc [audit Private Weapon](audit/cfm-private-weapon-export-2026-08-14.md) và giữ dữ liệu trong phạm vi private.

## Việc còn mở

Không còn bước bắt buộc của migration ảnh. Chỉ tiếp tục khi người dùng giao hạng mục mới:

- upload thư mục thật và kiểm tra thư mục con;
- xác định điều kiện sinh node Tổng hợp/So sánh;
- kiểm thử nhiều chu kỳ Google Drive: thêm, sửa, đổi tên, di chuyển, xóa và thay quyền;
- kiểm chứng connector Notion/NAS bằng credential test quyền tối thiểu.
- chẩn đoán Image Analysis: composer có preview nhưng request test hiện trả Unsupported format;
- kiểm chứng audio/ASR khi tenant được cấp model và kiểm tra lại quota model;
- kiểm thử chia sẻ end-to-end và khôi phục sau xóa Agent khi người dùng cho phép đối tượng test mới.
- nếu muốn dùng `Data Private Weapon` cho Agent/RAG: chọn KB private đích, quyền truy cập, retention, phương án ẩn danh/tối thiểu hóa, giới hạn dung lượng và test parser trước khi upload; không mặc định trộn vào `Knowledge VNG AI`.
- nếu cần dữ liệu ngoài sáu dataset nhúng trong HTML: cung cấp file `cfm-hub-data-cb-weapons.js` đang được HTML tham chiếu nhưng không có cạnh file nguồn.

`Test Doc RAG+Wiki` cũ đã bị xóa. Mọi test Documents/Wiki/Graph mới cần một KB test mới được người dùng cho phép.

## Lệnh chuẩn

```powershell
python scripts\build_handbook.py
python -m unittest discover -s tests -v
```

Chỉ chạy builder khi nhiệm vụ cho phép ghi artifact. Bản bàn giao phải dùng strict build, không dùng `--allow-missing-minio`.

## Quy tắc sống còn

- Không xóa asset KB hoặc bất kỳ ảnh nào trong 49 PNG khi Markdown còn tham chiếu URI MinIO.
- Không nạp PNG độc lập vào consumer; thay ảnh phải đi theo thứ tự asset host → map → build → thay MD → chat test → cleanup consumer.
- Agent nghiệp vụ chỉ bind `Knowledge VNG AI`; không dùng `Knowledge VNG - Image Assets` làm corpus trả lời thông thường.
- Cấu hình Intent/prompt/switch trong UI và hành vi runtime là hai lớp bằng chứng riêng; không nâng kết quả Có điều kiện thành mặc định.
- Nút **Hủy** trong hộp tiến trình hủy pipeline, không chỉ đóng hộp. Trường hợp file 11 từng cần parser **Simple** được ghi tại [audit retry](audit/consumer-markdown-retry-2026-08-07.json); không suy rộng thành mặc định.
- Không lưu credential, service-account JSON, token hoặc private key trong workspace/audit.
- Không upload `Data Private Weapon` vào consumer/asset KB hoặc chia sẻ rộng khi chưa có phê duyệt rõ ràng; không ghi giá trị định danh/giao dịch cụ thể vào audit, status hoặc handoff.
- Không coi mirror tại `J:\My Drive\CFL\KB VNG` là nguồn sửa sổ tay hoặc bằng chứng inventory live.

## Bằng chứng mới nhất

- [Snapshot live cuối](audit/final-live-inventory-2026-08-07.json)
- [Audit migration ảnh](audit/audit-image-assets-migration-2026-08-07.md)
- [Tiến độ đã đóng](docs/superpowers/reports/2026-08-07-image-assets-kb-migration-progress.md)
- [Verification cuối](docs/superpowers/reports/task-10-final-verification.md)
- [13 knowledge ID nền ngày 07/08](audit/consumer-markdown-new-knowledge-ids-2026-08-07.json)
- [Snapshot live Agent cuối](audit/final-agent-live-inventory-2026-08-11.json)
- [Audit Agent](audit/agent-live-test-2026-08-11.md)
- [9 ID/URI ảnh Agent](audit/agent-image-assets-knowledge-ids-2026-08-11.json)
- [ID module Agent](audit/agent-markdown-knowledge-id-2026-08-11.json)
- [Chat nguồn và ảnh](audit/agent-final-chat-source-and-image-2026-08-11.png)
- [Verification Agent cuối](docs/superpowers/reports/2026-08-11-agent-final-verification.md)
- [Audit rollout Agent chuyên sâu](audit/agent-deep-test-2026-08-11.md)
- [15 ID/URI asset Agent chuyên sâu](audit/agent-deep-image-assets-knowledge-ids-2026-08-11.json)
- [Backup module Agent legacy](audit/13-tao-va-van-hanh-agent-before-v3.3.0.md)
- [Snapshot inventory live v3.3.0](audit/final-live-inventory-2026-08-12.json)
- [Verification rollout v3.3.0](docs/superpowers/reports/2026-08-12-agent-v3.3-rollout.md)
- [Audit export dữ liệu Private Weapon](audit/cfm-private-weapon-export-2026-08-14.md)
