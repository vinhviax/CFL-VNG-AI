# Quy tắc làm việc — Knowledge Base VNG

## Phạm vi áp dụng

Các quy tắc này áp dụng cho toàn bộ workspace `J:\My Drive\AI\Knowledge Base VNG`. Chúng hướng dẫn cách bảo trì tài liệu, artifact và kiểm chứng; không thay thế nội dung nghiệp vụ trong master.

## Thứ tự đọc khi bắt đầu phiên

1. [HANDOFF.md](HANDOFF.md) để biết việc tiếp theo của phiên trước.
2. [STATUS.md](STATUS.md) để xem ảnh chụp trạng thái có ngày và các việc còn mở.
3. [PROJECT.md](PROJECT.md) để hiểu phạm vi và cấu trúc ổn định của dự án.
4. [DECISIONS.md](DECISIONS.md) để hiểu các lựa chọn cần được giữ nhất quán.
5. [so-tay-tao-knowledge-base-v3.md](so-tay-tao-knowledge-base-v3.md) khi cần nội dung nghiệp vụ chuẩn; [audit nền 06/08/2026](audit/audit-knowledge-vng-2026-08-06.md), [audit Google Drive 07/08/2026](audit/audit-google-drive-connector-2026-08-07.md), [audit Agent 11/08/2026](audit/agent-live-test-2026-08-11.md) và các snapshot trong [audit](audit/) khi cần bằng chứng có ngày.

## Nguồn chuẩn và artifact sinh tự động

- `so-tay-tao-knowledge-base-v3.md` là nguồn nội dung chuẩn duy nhất, phiên bản 3.3.0, cập nhật 11/08/2026.
- `knowledge-vng/*.md` là 20 module sinh tự động; không sửa trực tiếp.
- `so-tay-tao-knowledge-base.html` là HTML sinh tự động; không sửa trực tiếp.
- `knowledge-vng/assets/*.png` gồm 49 asset local dùng cho bản đọc và HTML offline. `knowledge-vng/image-map.json` ánh xạ đúng 49 tên này sang 49 URI MinIO duy nhất của KB asset chuyên dụng; metadata phải giữ `knowledge_base`, `knowledge_base_id`, `tenant_id`, `purpose`, `provenance` và `images` nhất quán.
- 20 module hiện có 60 liên kết ảnh hoạt động dạng `minio://` và 60 comment `LOCAL_ASSET`, cùng quy về 49 asset duy nhất. Liên kết MinIO phục vụ Knowledge VNG chat; `LOCAL_ASSET` chỉ là metadata cho builder tìm ảnh local và dựng HTML offline.
- `AGENTS.md`, `PROJECT.md`, `STATUS.md`, `HANDOFF.md` và `DECISIONS.md` chỉ là tài liệu vận hành/bàn giao; không là nguồn thay thế để sửa nội dung sổ tay.

## Kiến trúc hai KB

- **KB asset:** `Knowledge VNG - Image Assets`, ID `6da8657c-dd96-4170-a698-074043475014`, tenant `10012`. KB này giữ đúng 49 PNG nguồn, không nhận Markdown và là dependency lâu dài của mọi module còn tham chiếu URI do nó cấp.
- **KB sử dụng:** `Knowledge VNG AI`, ID `cefadf09-4187-46ac-a765-591e3255a4a4`, tenant `10012`. Trạng thái đích bền vững của KB này là chỉ có 20 Markdown sinh tự động, không giữ PNG độc lập.
- Luồng phân phối là asset local → KB asset → `image-map.json` → build nghiêm ngặt → 20 Markdown → KB sử dụng. HTML offline đi trực tiếp từ master và asset local, không phụ thuộc URI live khi đọc.
- Agent nghiệp vụ dùng `Knowledge VNG AI` làm nguồn trả lời; không chọn KB asset làm corpus thông thường. Cấu hình Intent/prompt trong UI chỉ chứng minh thiết lập và định tuyến dự kiến; hành vi runtime phải được kiểm chứng riêng bằng chat, nguồn tham khảo và bằng chứng có ngày.
- Trạng thái xử lý tạm thời của từng tài liệu live phải nằm trong audit/`STATUS.md`/`HANDOFF.md`, không được ghi thành kiến trúc ổn định tại ba file này.

## Vùng được sửa

Chỉ sửa master, script, mẫu, test, audit và tài liệu bàn giao khi nhiệm vụ hiện tại cho phép rõ ràng. Mọi thay đổi nội dung sổ tay bắt đầu ở master, không bắt đầu ở module hoặc HTML. Giữ nguyên các asset local đang được dùng và mapping MinIO tương ứng trừ khi thay đổi có kế hoạch thay thế đầy đủ và đã được kiểm chứng.

## An toàn khi kiểm tra Knowledge VNG live

- Trong luồng ảnh hiện tại, chỉ thao tác trên đúng KB asset và KB sử dụng nêu trên khi nhiệm vụ cho phép rõ ràng. Các KB test trong audit cũ là bằng chứng lịch sử, không tự động cấp quyền mutation cho phiên mới.
- KB `Test Doc RAG+Wiki` trong audit 06/08/2026 đã bị người dùng xóa; chỉ được trích dẫn như bằng chứng lịch sử, không phải dependency hoặc đích thao tác còn tồn tại.
- Không tạo, sửa, xóa hay thay thế dữ liệu ở KB khác; không tác động dữ liệu không liên quan trong `Knowledge VNG AI`; không dùng credential thật trong tài liệu hoặc kiểm tra.
- Không dùng **Thay toàn bộ** ngoài KB test. Trước thao tác nhập có ảnh hưởng, xuất backup và ưu tiên thử **Thêm vào**.
- Không xóa KB `Knowledge VNG - Image Assets` hoặc bất kỳ ảnh nguồn nào còn cung cấp URI `minio://` cho Markdown phân phối, kể cả khi link vẫn tạm thời render sau thao tác xóa.
- Ghi kết quả live vào audit trước; mọi trạng thái live phải có ngày kiểm chứng và liên kết tới bằng chứng, đồng thời phân loại đúng là Đã kiểm chứng, Có điều kiện hoặc Bị chặn/Chưa xác định.

## Toàn vẹn ảnh và checkpoint phục hồi

- File mang đuôi `.png` phải có payload PNG thật và bắt đầu bằng 8 magic bytes `89 50 4E 47 0D 0A 1A 0A`. Không đổi đuôi JPEG thành `.png`; nếu nguồn là JPEG, phải transcode sang PNG thật rồi kiểm tra lại signature trước khi upload hoặc build.
- Giữ snapshot mapping trước migration tại [image-map-before-assets-migration-2026-08-07.json](audit/image-map-before-assets-migration-2026-08-07.json) và backup nguyên byte 14 JPEG từng bị gắn sai đuôi tại [image-assets-original-jpeg-mislabeled-2026-08-07](audit/image-assets-original-jpeg-mislabeled-2026-08-07/).
- Định danh 25 ảnh nền nằm trong [image-assets-knowledge-ids-2026-08-07.json](audit/image-assets-knowledge-ids-2026-08-07.json); 9 ảnh Agent nằm trong [agent-image-assets-knowledge-ids-2026-08-11.json](audit/agent-image-assets-knowledge-ids-2026-08-11.json); danh sách 14 bản sai định dạng đã được thay nằm trong [image-assets-replaced-knowledge-ids-2026-08-07.json](audit/image-assets-replaced-knowledge-ids-2026-08-07.json). Không sửa snapshot để khớp trạng thái mới.

## Quy trình thay đổi nội dung sổ tay

1. Sửa `so-tay-tao-knowledge-base-v3.md` và giữ cặp marker `MODULE` của 20 phần.
2. Nếu thay ảnh, đi đúng thứ tự: cập nhật và kiểm tra PNG local → nạp/xác nhận ảnh ở KB asset → cập nhật map và metadata → build nghiêm ngặt → phát hành Markdown liên quan trong KB sử dụng → chat test và mở nguồn tham khảo → chỉ sau đó dọn PNG độc lập khỏi KB sử dụng.
3. Khi thay từng Markdown live, chỉ gỡ bản cũ sau khi bản mới xử lý xong và đã kiểm tra đúng nội dung/URI; không xóa ảnh ở KB asset trong bước cleanup consumer.
4. Chạy build rồi toàn bộ test.
5. Nếu có kiểm chứng live mới, cập nhật audit với ngày và bằng chứng trước.
6. Cập nhật `STATUS.md` với ảnh chụp trạng thái có ngày, rồi cập nhật `HANDOFF.md` ở cuối phiên với việc đã làm, việc chưa làm, bằng chứng và bước tiếp theo.

## Lệnh build và test

```powershell
python scripts\build_handbook.py
python -m unittest discover -s tests -v
```

Lệnh build phải chạy ở chế độ nghiêm ngặt (không dùng `--allow-missing-minio` cho kết quả bàn giao). Build phải báo `Build complete`, 20 module và HTML offline; baseline ngày 12/08/2026 của toàn bộ test phải kết thúc với `Ran 13 tests` và `OK`. Builder là thao tác ghi lên module/HTML sinh tự động, nên chỉ chạy khi scope cho phép ghi các artifact này.

## Tiêu chí hoàn tất

- Nội dung nghiệp vụ được thay đổi tại master, sau đó build sinh lại 20 module và HTML offline.
- Build nghiêm ngặt và toàn bộ test hiện có đều thành công.
- Có đúng 49 PNG local với magic bytes hợp lệ, 49 mapping/URI MinIO duy nhất của KB asset, 60 link ảnh hoạt động và 60 `LOCAL_ASSET`; không có link ảnh local hoạt động trong module.
- KB asset vẫn giữ 49 PNG; KB sử dụng chỉ giữ 20 Markdown sau khi quy trình phát hành và chat test hoàn tất.
- Kết quả live có ngày, audit và bằng chứng; mục có điều kiện hoặc bị chặn không bị trình bày như kết luận chắc chắn.
- `STATUS.md` và `HANDOFF.md` được cập nhật trước khi kết thúc phiên nếu thay đổi ảnh hưởng trạng thái hoặc hướng tiếp tục.
