# Trạng thái Knowledge Base VNG

**Ngày snapshot:** 14/08/2026  
**Phiên bản:** 3.3.0  
**Giai đoạn:** Sẵn sàng bảo trì; rollout Agent chuyên sâu đã đóng; đã bổ sung bản phân phối local và dữ liệu Private Weapon, không có mutation live mới.

## Kết quả hiện tại

- `Knowledge VNG - Image Assets` (`6da8657c-dd96-4170-a698-074043475014`, tenant `10012`): **49 PNG, 0 MD**, 49/49 **Hoàn tất**.
- `Knowledge VNG AI` (`cefadf09-4187-46ac-a765-591e3255a4a4`, tenant `10012`): **20 MD, 0 PNG**, 20/20 **Hoàn tất**.
- Bảy module Agent `13-agent-tong-quan-va-kien-truc.md` đến `19-vong-doi-phan-quyen-quan-sat-va-bao-tri.md` đã được chat-test: mỗi module có source drawer đúng file và ảnh render. Bản legacy `13-tao-va-van-hanh-agent.md` đã được backup rồi xóa an toàn.
- Hậu kiểm no-hit: câu hỏi chính sách nghỉ phép 2031 trả lời không có thông tin trong KB, không tạo chính sách tưởng tượng.
- Đã dọn KB `TEST - Agent Deep Audit 2026-08-11` và hai Agent lifecycle TEST sau audit; sáu Agent mặc định và hai Agent kiểm thử hiện hữu được giữ nguyên.

## Workspace làm việc CFL

- Root làm việc được người dùng chỉ định: `J:\My Drive\CFL\KB VNG`.
- `Knowledge VNG AI`: 20 Markdown local, tổng 123.785 byte.
- `Knowledge VNG - Image Assets`: 49 PNG local, tổng 21.393.824 byte.
- `Data Private Weapon`: 7 CSV + 1 JSON raw, tổng 51.345.189 byte. Riêng 7 CSV có 388.820 dòng dữ liệu và 25.391.930 byte.
- Xác minh lại ngày 14/08/2026: đúng 7 file CSV, UTF-8 hợp lệ, số dòng/cột đạt và record đầu/cuối của từng file khớp JSON nguồn. Không còn file `.partial`.
- Đây là trạng thái filesystem local/Google Drive, không phải inventory live Knowledge VNG. Không có file nào trong `Data Private Weapon` được upload vào hai KB hiện hành.

## Artifact local và gate phát hành

| Hạng mục | Trạng thái hiện hành |
|---|---|
| Master | `so-tay-tao-knowledge-base-v3.md`, v3.3.0 |
| Markdown phân phối | 20 module sinh tự động |
| Ảnh | 49 PNG có signature hợp lệ |
| Mapping | 49 tên asset → 49 URI `.png` MinIO duy nhất |
| Liên kết ảnh | 60 MinIO + 60 `LOCAL_ASSET`; không có link ảnh local hoạt động |
| HTML | Một file offline tự chứa CSS, JavaScript và ảnh |
| Verification | Strict build PASS; `Ran 13 tests`; source/ảnh module 13–19 và no-hit PASS; reviewer độc lập **APPROVED** |

## Backlog chưa xác thực

| Ưu tiên | Hạng mục | Điều kiện tiếp tục |
|---|---|---|
| P1 | Upload thư mục thật và cấu trúc thư mục con | Có bộ dữ liệu test và quyền mutation live |
| P2 | Điều kiện sinh node Tổng hợp/So sánh | Có KB test mới được người dùng cho phép |
| P3 | Ma trận đồng bộ Google Drive nhiều chu kỳ | Có bộ dữ liệu đối chứng cho thêm/sửa/đổi tên/di chuyển/xóa/quyền |
| P4 | Connector Notion/NAS | Có credential test quyền tối thiểu |
| P5 | Image Analysis attachment | Có lượt test mới để xác định vì sao preview composer không đi vào request Agent |
| P6 | Audio/ASR và quota model | Tenant được cấp ASR và quota model test ổn định |
| P7 | Chia sẻ/xóa Agent end-to-end | Người dùng cho phép mutation chia sẻ hoặc xóa trên đối tượng test mới |
| P8 | Thiết kế nạp `Data Private Weapon` cho Agent/RAG | Chỉ tiếp tục khi người dùng chọn KB private đích, quyền truy cập, retention, ẩn danh/tối thiểu hóa dữ liệu và kế hoạch test parser; không mặc định dùng `Knowledge VNG AI` |

## Lưu ý vận hành hiện hành

- `Test Doc RAG+Wiki` đã bị xóa; chỉ còn giá trị lịch sử trong audit.
- Không xóa `Knowledge VNG - Image Assets` hoặc ảnh đang cấp URI.
- Nút **Hủy** trong progress dialog hủy pipeline. File 11 từng hoàn tất bằng override parser **Simple**; đây là workaround có ngày, không phải mặc định chung.
- Nội dung chỉ sửa tại master; module Markdown và HTML là artifact sinh tự động.
- Agent nghiệp vụ dùng consumer làm nguồn trả lời; không chọn KB asset làm corpus thông thường.
- Intent là tuyến xử lý/prompt theo loại yêu cầu. Việc control lưu được không tự chứng minh runtime; xem audit 11/08 cho Image Analysis, ASR, quota và raw chunk handle có điều kiện.
- Agent test, bản sao, hai chat/feedback test được giữ làm bằng chứng; không xem chúng là Agent production hoặc phản hồi người dùng thật.
- `Data Private Weapon` chứa định danh và dữ liệu hành vi/tài chính liên quan người dùng. Không chép giá trị cụ thể vào tài liệu, không nạp vào KB chia sẻ rộng và không trộn vào consumer tài liệu nếu chưa có phê duyệt rõ ràng.
- HTML nguồn tham chiếu `cfm-hub-data-cb-weapons.js` nhưng file này không có cạnh HTML ngày kiểm tra; bản export chỉ bao gồm sáu dataset được nhúng trực tiếp trong HTML.

## Bằng chứng

- [Snapshot live cuối](audit/final-live-inventory-2026-08-07.json)
- [Audit migration tổng hợp](audit/audit-image-assets-migration-2026-08-07.md)
- [Tiến độ migration đã đóng](docs/superpowers/reports/2026-08-07-image-assets-kb-migration-progress.md)
- [Verification cuối](docs/superpowers/reports/task-10-final-verification.md)
- [Snapshot live Agent cuối](audit/final-agent-live-inventory-2026-08-11.json)
- [Audit Agent](audit/agent-live-test-2026-08-11.md)
- [9 ID/URI ảnh Agent](audit/agent-image-assets-knowledge-ids-2026-08-11.json)
- [ID module Agent](audit/agent-markdown-knowledge-id-2026-08-11.json)
- [Verification Agent cuối](docs/superpowers/reports/2026-08-11-agent-final-verification.md)
- [Audit Agent chuyên sâu và rollout](audit/agent-deep-test-2026-08-11.md)
- [15 ID/URI ảnh Agent chuyên sâu](audit/agent-deep-image-assets-knowledge-ids-2026-08-11.json)
- [Backup module 13 legacy](audit/13-tao-va-van-hanh-agent-before-v3.3.0.md)
- [Snapshot inventory live v3.3.0](audit/final-live-inventory-2026-08-12.json)
- [Verification rollout v3.3.0](docs/superpowers/reports/2026-08-12-agent-v3.3-rollout.md)
- [Audit export dữ liệu Private Weapon](audit/cfm-private-weapon-export-2026-08-14.md)
