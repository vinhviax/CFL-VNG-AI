# Knowledge Base VNG — Tổng quan dự án

## Mục tiêu

Đóng gói một sổ tay đã được kiểm chứng để người dùng Knowledge VNG có thể tạo, cấu hình, nạp dữ liệu, kiểm thử và bảo trì Knowledge Base, đồng thời tạo và vận hành Agent dùng KB để chat với Human. Dự án phát hành cùng lúc master dễ bảo trì, Markdown sẵn nạp cho Knowledge VNG và HTML có thể đọc hoàn toàn offline. Master hiện là phiên bản 3.3.0, cập nhật 11/08/2026.

## Trạng thái triển khai hiện tại

Bản v3.3.0 tách Agent thành bảy module 13–19 cho cả vận hành lẫn kỹ thuật. Kiến trúc đích live là 49 PNG trong asset KB và 20 Markdown trong consumer; Agent nghiệp vụ truy hồi consumer, không dùng asset KB làm corpus. Snapshot thay đổi theo thời gian nằm trong [STATUS.md](STATUS.md); bằng chứng Agent có ngày nằm trong [audit deep Agent](audit/agent-deep-test-2026-08-11.md).

Từ ngày 12/08/2026, `J:\My Drive\CFL\KB VNG` là root làm việc bên ngoài workspace cho các thư mục KB và dữ liệu phục vụ công việc CFL. Đây là vùng lưu bản phân phối/dữ liệu làm việc, không thay thế master, builder hoặc artifact nguồn trong workspace này. Snapshot ngày 14/08/2026 được ghi tại [audit dữ liệu Private Weapon](audit/cfm-private-weapon-export-2026-08-14.md); việc tạo bản CSV không làm thay đổi inventory live của hai KB.

## Đối tượng sử dụng

- Người mới vận hành Knowledge Base trên Knowledge VNG.
- Người biên soạn hoặc bảo trì nội dung hướng dẫn.
- Agent/nhân sự nhận bàn giao cần cập nhật sổ tay mà không tác động sai artifact hoặc dữ liệu live.

## Năm nhóm đầu ra

1. Master nghiệp vụ: [so-tay-tao-knowledge-base-v3.md](so-tay-tao-knowledge-base-v3.md).
2. Gói nạp Knowledge VNG: 20 module Markdown sinh trong [knowledge-vng](knowledge-vng/), gồm module Google Drive và bảy module Agent chuyên sâu.
3. Bản đọc offline: [so-tay-tao-knowledge-base.html](so-tay-tao-knowledge-base.html), tự chứa CSS, JavaScript và ảnh data URI.
4. Tài sản hỗ trợ: 49 PNG local, mapping MinIO của KB asset, mẫu FAQ/DOC, audit, backup và bằng chứng kiểm chứng.
5. Tài liệu vận hành/bàn giao: `AGENTS.md`, `PROJECT.md`, `STATUS.md`, `HANDOFF.md` và `DECISIONS.md`.

## Luồng tạo artifact

`so-tay-tao-knowledge-base-v3.md` là đầu vào của [scripts/build_handbook.py](scripts/build_handbook.py). Builder trích đúng 20 cặp marker `MODULE`, tạo 20 Markdown trong `knowledge-vng/`, thay ảnh hoạt động trong Markdown bằng URI MinIO từ `knowledge-vng/image-map.json`, thêm comment `LOCAL_ASSET` tương ứng và sinh một HTML offline từ master cùng asset local. Vì vậy module và HTML luôn là đầu ra, không phải nơi sửa nội dung.

```text
49 PNG local ──> HTML offline (ảnh data URI)
      │
      └──> Knowledge VNG - Image Assets (49 PNG)
                    │
                    └──> image-map.json (49 URI minio://)
                                  │
master + map ──> strict builder ──> 20 Markdown ──> Knowledge VNG AI ──> Agent ──> Human
```

## Cây thư mục chính

```text
.
├── so-tay-tao-knowledge-base-v3.md   # master nghiệp vụ
├── so-tay-tao-knowledge-base.html    # HTML sinh tự động, offline
├── knowledge-vng/                    # 20 module sinh tự động, 49 PNG và image-map.json
├── scripts/                           # builder
├── tests/                             # kiểm tra build hồi quy
├── samples/                           # mẫu nội dung/FAQ
├── audit/                             # nhật ký và bằng chứng kiểm chứng live
├── docs/superpowers/                  # brief, thiết kế, kế hoạch và báo cáo bàn giao
├── AGENTS.md                          # quy tắc làm việc
├── PROJECT.md                         # bối cảnh ổn định (file này)
├── STATUS.md                          # trạng thái có ngày
├── HANDOFF.md                         # điểm vào phiên tiếp theo
└── DECISIONS.md                       # lý do các quyết định bền vững
```

## Root làm việc CFL và dữ liệu riêng tư

Các thư mục thuộc phạm vi dự án đã được xác minh dưới `J:\My Drive\CFL\KB VNG`:

| Thư mục | Vai trò | Snapshot 14/08/2026 |
|---|---|---|
| `Knowledge VNG AI` | Bản phân phối local để dùng ngoài workspace | 20 Markdown, 0 PNG |
| `Knowledge VNG - Image Assets` | Bản sao asset local theo tên KB asset | 49 PNG, 0 Markdown |
| `Data Private Weapon` | Dữ liệu CFL riêng tư đã tách từ HTML | 7 CSV + 1 JSON raw; 388.820 dòng CSV |

Hai thư mục mang tên KB là bản local để trao đổi/làm việc, không phải nguồn chuẩn để sửa sổ tay và không tự chứng minh trạng thái live. Nguồn chuẩn vẫn là master, asset local và builder trong workspace `J:\My Drive\AI\Knowledge Base VNG`.

`Data Private Weapon` có các trường định danh và hành vi như `openid`, `roleid`, nickname, hạng thành viên, lịch sử nạp và số trận. Dữ liệu này không thuộc corpus tài liệu vận hành `Knowledge VNG AI`, không được tự động upload vào consumer hoặc asset KB, và không được ghi giá trị cá nhân cụ thể vào audit/handoff. Nếu cần dùng cho RAG/Agent, phải có chỉ định đích riêng, quyền truy cập, phạm vi lưu giữ, phương án tối thiểu hóa/ẩn danh và kiểm thử parser trước khi mutation live.

## Hợp đồng artifact ảnh

Mỗi ảnh hướng dẫn có hai vai trò. PNG local trong `knowledge-vng/assets/` phục vụ người đọc và được nhúng thành data URI trong HTML offline; URI `minio://` tương ứng phục vụ Knowledge VNG chat render ảnh từ Markdown nạp. `LOCAL_ASSET` chỉ ghi đường dẫn local cho builder, không phải nguồn ảnh mà chat tải.

Filesystem ngày 12/08/2026 có các invariant sau:

| Hạng mục | Hợp đồng ổn định |
|---|---|
| Asset local | 49 file `.png`, mỗi file có signature PNG `89 50 4E 47 0D 0A 1A 0A` |
| `image-map.json` | 49 key khớp tên asset, 49 URI duy nhất dạng `minio://knowledge-base-prd/10012/exports/*.png` |
| Metadata map | `Knowledge VNG - Image Assets`, ID `6da8657c-dd96-4170-a698-074043475014`, tenant `10012`, provenance tách ảnh nền 01–25, Agent 26–34 và Agent deep 35–49 |
| 20 module | 60 link ảnh MinIO hoạt động và 60 comment `LOCAL_ASSET`; 49 asset duy nhất được dùng lặp lại ở một số module |
| HTML | Một file offline tự chứa CSS, JavaScript và payload ảnh local; không cần tài nguyên ảnh live khi đọc |

Không được đổi đuôi JPEG thành `.png`. Ảnh phải được transcode sang payload PNG thật và kiểm tra magic bytes trước khi nạp. Khi Markdown còn tham chiếu URI, KB/ảnh đã cấp URI là dependency và không được xóa.

## Kiến trúc hai KB

| Vai trò | Knowledge Base | Nội dung bền vững | Quy tắc |
|---|---|---|---|
| Asset host | `Knowledge VNG - Image Assets` — `6da8657c-dd96-4170-a698-074043475014`, tenant `10012` | 49 PNG, không có MD | Sở hữu vòng đời ảnh và cấp URI MinIO; không dùng làm KB hỏi đáp cho người dùng cuối |
| Consumer | `Knowledge VNG AI` — `cefadf09-4187-46ac-a765-591e3255a4a4`, tenant `10012` | Chỉ 20 MD sinh tự động, không có PNG | Nhận bộ Markdown đã build và phục vụ chat/kiểm thử sổ tay, gồm bảy module Agent |

Nếu thay ảnh hoặc đổi host, trình tự bắt buộc là **asset host → map → strict build → phát hành MD → chat test → cleanup consumer PNG**. Chỉ cleanup PNG độc lập trong consumer sau khi ảnh đã render và nguồn tham khảo dùng đúng URI mới; tuyệt đối không cleanup PNG trong asset host khi Markdown còn tham chiếu.

Agent nghiệp vụ phải chọn `Knowledge VNG AI` làm KB trả lời; `Knowledge VNG - Image Assets` chỉ phục vụ URI ảnh. Ý nghĩa Intent, model, quota và các switch được tách thành hai lớp bằng chứng: cấu hình UI và hành vi chat runtime. Không suy diễn một switch lưu thành công là Intent/VLM/ASR đã chạy thành công.

Hai KB test cũ trong [audit nền 06/08/2026](audit/audit-knowledge-vng-2026-08-06.md) và bằng chứng connector trong [audit Google Drive 07/08/2026](audit/audit-google-drive-connector-2026-08-07.md) là bối cảnh kiểm chứng lịch sử, không phải dependency của pipeline ảnh hiện tại và không tự động là đích được phép mutation.

Riêng `Test Doc RAG+Wiki` đã bị người dùng xóa sau lượt audit; mọi ID, Graph snapshot và ảnh từ KB đó chỉ có giá trị lịch sử. Kiểm thử Documents/Wiki/Graph mới cần một KB test mới được người dùng chỉ định hoặc cho phép.

## Backup, audit và verification

- [Snapshot image map trước migration](audit/image-map-before-assets-migration-2026-08-07.json) giữ nguyên URI cũ để phục hồi/đối chiếu.
- [Backup 14 JPEG từng gắn sai đuôi](audit/image-assets-original-jpeg-mislabeled-2026-08-07/) giữ nguyên byte nguồn; [audit ID hiện hành](audit/image-assets-knowledge-ids-2026-08-07.json) và [audit ID đã thay](audit/image-assets-replaced-knowledge-ids-2026-08-07.json) ghi lại chuyển đổi sang PNG thật.
- [Audit migration ảnh](audit/audit-image-assets-migration-2026-08-07.md) tổng hợp mapping 25 ảnh, thay 13 Markdown, chat test và inventory live cuối.
- [Verification cuối](docs/superpowers/reports/task-10-final-verification.md) ghi nhận strict build, 11/11 test, inventory live và review độc lập APPROVED.
- [Audit deep Agent](audit/agent-deep-test-2026-08-11.md) ghi ma trận tính năng, Intent, model/quota, chat, feedback, attachment, cleanup và các giới hạn có điều kiện.
- [Định danh 15 ảnh Agent deep](audit/agent-deep-image-assets-knowledge-ids-2026-08-11.json) ghi knowledge ID và URI MinIO của ảnh 35–49.
- [Snapshot live v3.3.0](audit/final-live-inventory-2026-08-12.json) ghi inventory 49 PNG/20 Markdown sau rollout và cleanup TEST.
- [Audit dữ liệu Private Weapon](audit/cfm-private-weapon-export-2026-08-14.md) ghi nguồn HTML, 7 CSV, số dòng, checksum và giới hạn dữ liệu riêng tư; không chứa giá trị người dùng cụ thể.

Lệnh chuẩn từ root workspace:

```powershell
python scripts\build_handbook.py
python -m unittest discover -s tests -v
```

Build bàn giao luôn là strict build, không dùng `--allow-missing-minio`; output phải có `Build complete`, 20 module và HTML offline. Baseline test ngày 12/08/2026 là `Ran 13 tests` và `OK`.

## Giới hạn phạm vi

Sổ tay chỉ khẳng định thao tác Knowledge VNG có bằng chứng nội bộ. Trạng thái giao diện và các kết quả phụ thuộc quyền, model, credential hoặc dữ liệu phải có ngày kiểm chứng và dẫn chiếu audit. Trạng thái tạm thời của một tài liệu live không được đưa vào bối cảnh ổn định ở file này. Không mở rộng phạm vi sang quản trị production, lưu credential thật, hay suy luận hành vi connector/đồng bộ chưa được kiểm chứng. Nội dung nghiệp vụ chuẩn vẫn chỉ nằm ở master.
